
function netejarText() {
    const input = document.getElementById("inputText").value;
    const cleaned = input.replace(/[^ -]|[#]/g, '');
    document.getElementById("previewBox").innerText = cleaned;
}

function reestructurarText() {
    const input = document.getElementById("inputText").value;
    const cleaned = input.replace(/[^ -]|[#]/g, '');
    const structured = cleaned.split('. ').map(sentence => sentence.trim()).join('.\n');
    document.getElementById("previewBox").innerText = structured;
}

function professionalizePrompt() {
    const input = document.getElementById("inputText").value;
    const cleaned = input.replace(/[^ -]|[#]/g, '');
    const professional = "Please rewrite this professionally:\n" + cleaned;
    document.getElementById("previewBox").innerText = professional;
}

function copiarText() {
    const text = document.getElementById("previewBox").innerText;
    navigator.clipboard.writeText(text);
    alert("Prompt copied!");
}
